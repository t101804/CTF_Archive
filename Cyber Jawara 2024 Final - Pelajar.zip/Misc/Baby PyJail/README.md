# Baby PyJail [500 pts]

**Category:** Misc
**Solves:** 0

## Description
>Break the jail and get the flag.

**Hint**
* -

## Solution

### Flag

