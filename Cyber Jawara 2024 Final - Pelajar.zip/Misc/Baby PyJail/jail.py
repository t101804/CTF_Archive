#!/usr/local/bin/python3 -S

def run_code(code):
    e(code, {'__builtins__': None})

i, e = input, exec
user_input = i('>>> ')

try:
    run_code(user_input)
except:
    pass
