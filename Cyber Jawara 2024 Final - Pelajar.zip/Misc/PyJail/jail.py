#!/usr/local/bin/python3 -S

BANNED = '012345678}!<%[$/#{+`*;~>\'\\&-(]=|"^?,)'

def run_code(code):
    for char in set(code):
        assert char not in BANNED, ':x'

    __builtins__.__dict__.clear()
    
    safe_builtins = {'__build_class__': err}
    e(code, {'__builtins__': safe_builtins})

i, e, err = input, exec, RuntimeError
user_input = i('>>> ')

try:
    run_code(user_input)
except:
    pass
