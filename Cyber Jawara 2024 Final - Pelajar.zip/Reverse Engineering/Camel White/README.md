# Camel White [500 pts]

**Category:** Reverse Engineering
**Solves:** 0

## Description
>My camel so slow

**Hint**
* -

## Solution

### Flag

