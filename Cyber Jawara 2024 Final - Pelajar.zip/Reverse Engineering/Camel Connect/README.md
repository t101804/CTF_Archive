# Camel Connect [500 pts]

**Category:** Reverse Engineering
**Solves:** 0

## Description
>Is there a connection between us? if so is it secure? seems likes nothing to me.

**Hint**
* -

## Solution

### Flag

