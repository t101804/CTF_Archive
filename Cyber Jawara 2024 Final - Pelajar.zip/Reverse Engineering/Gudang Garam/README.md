# Gudang Garam [500 pts]

**Category:** Reverse Engineering
**Solves:** 0

## Description
>Can you make something from this dump

**Hint**
* -

## Solution

### Flag

