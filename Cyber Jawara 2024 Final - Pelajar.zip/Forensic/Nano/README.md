# Nano [500 pts]

**Category:** Forensic
**Solves:** 0

## Description
>b"Our machine was compromised, but surprisingly, the attacker didnt create or modify any files. However, we recorded syscall activity that may give us a clue about what they did.\r\n\r\nhttps://drive.google.com/file/d/1P0cxPHMj5MvOhtO4ED-5nCCg4v74GTDV/view?usp=sharing"

**Hint**
* -

## Solution

### Flag

