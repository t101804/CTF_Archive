# C2 [500 pts]

**Category:** Forensic
**Solves:** 0

## Description
>We detected suspicious network traffic and think a compromised machine is communicating with a suspicious server.\r\n\r\nhttps://drive.google.com/file/d/1P0cxPHMj5MvOhtO4ED-5nCCg4v74GTDV/view?usp=sharing

**Hint**
* -

## Solution

### Flag

