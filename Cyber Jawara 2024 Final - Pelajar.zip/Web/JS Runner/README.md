# JS Runner [500 pts]

**Category:** We
**Solves:** 0

## Description
>Hey, I made a sandbox app, can you hack it

**Hint**
* -

## Solution

### Flag

