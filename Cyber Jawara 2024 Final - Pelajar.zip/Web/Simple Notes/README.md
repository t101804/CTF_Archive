# Simple Notes [500 pts]

**Category:** We
**Solves:** 0

## Description
>Simple note app for you.

**Hint**
* -

## Solution

### Flag

