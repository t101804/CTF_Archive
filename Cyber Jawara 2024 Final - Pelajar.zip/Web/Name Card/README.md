# Name Card [500 pts]

**Category:** We
**Solves:** 0

## Description
>Simple name card generator for you.

**Hint**
* -

## Solution

### Flag

