<?php

$config = array(
  'defaultFont' => 'Arial',
  'isRemoteEnabled' => true
);