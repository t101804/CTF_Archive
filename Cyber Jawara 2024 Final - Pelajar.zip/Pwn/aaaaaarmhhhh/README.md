# aaaaaarmhhhh [500 pts]

**Category:** Pwn
**Solves:** 0

## Description
>aaaaaarmhhhhaaaaaarmhhhhaaaaaarmhhhhaaaaaarmhhhhaaaaaarmhhhh\r\n\r\ncan you exploit this?

**Hint**
* -

## Solution

### Flag

