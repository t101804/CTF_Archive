# Sorting Game [500 pts]

**Category:** Pwn
**Solves:** 0

## Description
>This is like the 5th time ive made a sorting game challenge

**Hint**
* -

## Solution

### Flag

