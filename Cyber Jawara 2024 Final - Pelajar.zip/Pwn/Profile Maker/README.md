# Profile Maker [500 pts]

**Category:** Pwn
**Solves:** 0

## Description
>Welcome new hire, please fill in this data to receive your employee profile

**Hint**
* -

## Solution

### Flag

